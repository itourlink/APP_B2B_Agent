import { useListHotel } from '@/hooks/actions/useHotel';
import { useRouter } from '@/routes/hooks/use-router';
import { paths } from '@/routes/paths';
import { getUrlImage } from '@/utils/format-image';
import { formatPrice } from '@/utils/format-number';
import { Building2, MapPin, Star, LayoutGrid, List } from 'lucide-react';
import { useState } from 'react';

export const HotelCard = ({ hotel }: any) => {
    const router = useRouter()
    return (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col h-full group">
            <div className="relative h-44 overflow-hidden">
                <img
                    src={getUrlImage(hotel?.strSupplierImage)}
                    alt={hotel?.strSupplierName}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
            </div>

            <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-gray-800 font-bold text-[15px] leading-tight uppercase mb-4 h-12 line-clamp-2">
                    {hotel?.strSupplierName}
                </h3>

                <div className="space-y-2.5 mb-4 text-[13px] text-gray-600">
                    <div className="flex items-center gap-2">
                        <Building2 size={14} className="text-gray-400 shrink-0" />
                        <span>Khách sạn</span>
                        <div className="flex items-center ml-1">
                            { }
                            {[...Array(5)].map((_, i) => (
                                <Star
                                    key={i}
                                    size={14}
                                    className={i < hotel.intEasiaCateID ? "fill-orange-400 text-orange-400" : "text-gray-300"}
                                />
                            ))}
                        </div>
                    </div>

                    <div className="flex items-start gap-2">
                        <MapPin size={14} className="text-gray-400 mt-0.5 shrink-0" />
                        <span className="line-clamp-3 leading-relaxed">{hotel?.strSupplierAddr}</span>
                    </div>
                </div>

                <div className="mb-4 relative">
                    <div className="absolute inset-0 flex items-center" aria-hidden="true">
                        <div className="w-full border-t border-gray-100"></div>
                    </div>
                    <div className="relative flex justify-center">
                        <span className="bg-gray-50 px-3 text-[11px] font-bold text-gray-900 italic tracking-wider">
                            Tăng giá/Giảm giá
                        </span>
                    </div>
                </div>

                <div className="mt-auto flex items-end justify-between">
                    <div>
                        <p className="text-[11px] text-gray-500 mb-0.5">Giá từ</p>
                        <p className="text-[#2563eb] font-bold text-xl leading-none">
                            {formatPrice(hotel?.dblPriceFrom)}
                        </p>
                    </div>
                    <button onClick={() => router.replaceParams(paths.hotel.detail, { item: hotel })} className="cursor-pointer text-[#2563eb] border border-blue-200 hover:border-[#2563eb] hover:bg-blue-50 px-3 py-1.5 rounded-lg text-xs font-medium transition-all">
                        Xem chi tiết
                    </button>
                </div>
            </div>
        </div>
    );
};

const HotelList = () => {
    const [filters] = useState({
        page: 1,
        pageSize: 15,
        strSupplierGUID: null,
        tblsReturn: "[0]"
    });

    const { hotelData, hotelLoading, hotelError } = useListHotel(filters);

    return (
        <div className="max-w-7xl mx-auto p-6 bg-white min-h-screen">
            <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-bold text-gray-800">Khách Sạn Nổi Bật</h2>

                <div className="flex items-center gap-3 bg-gray-50 p-1 rounded-lg border border-gray-200">
                    <span className="text-[12px] text-gray-500 ml-2">Hiển thị dạng:</span>
                    <div className="flex gap-1">
                        <button className="p-1.5 bg-[#2566b0] text-white rounded-md">
                            <LayoutGrid size={16} />
                        </button>
                        <button className="p-1.5 text-gray-400 hover:bg-gray-200 rounded-md">
                            <List size={16} />
                        </button>
                    </div>
                </div>
            </div>

            {/* LOADING */}
            {hotelLoading && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                    {[...Array(8)].map((_, i) => (
                        <HotelCardSkeleton key={i} />
                    ))}
                </div>
            )}

            {/* ERROR */}
            {hotelError && <HotelError />}

            {/* DATA */}
            {!hotelLoading && !hotelError && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                    {hotelData?.map((hotel: any) => (
                        <HotelCard key={hotel?.strSupplierGUID} hotel={hotel} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default HotelList;


const HotelCardSkeleton = () => (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden p-4 animate-pulse">
        <div className="h-44 bg-gray-200 rounded mb-4" />
        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
        <div className="h-3 bg-gray-200 rounded w-1/2 mb-4" />
        <div className="h-3 bg-gray-200 rounded w-full mb-2" />
        <div className="h-3 bg-gray-200 rounded w-5/6 mb-4" />
        <div className="flex justify-between items-center">
            <div className="h-6 bg-gray-200 rounded w-1/3" />
            <div className="h-6 bg-gray-200 rounded w-1/4" />
        </div>
    </div>
);

const HotelError = () => (
    <div className="text-center py-20 text-red-500">
        Không tải được danh sách khách sạn
    </div>
);