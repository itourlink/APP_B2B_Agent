import { memo } from "react";

interface Props {
  currentColor?: string;
  width?: string;
  height?: string;

}

const VoucherIcon = ({ width = "24px", height = "24px" }: Props) => {
  return (
    <svg width={width} height={height} viewBox="0 0 15 15" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="currentColor" clip-rule="evenodd" d="M4.5 0C3.11929 0 2 1.11929 2 2.5V2.78571C2 3.23408 2.13327 3.65133 2.36235 4H1.5C0.671573 4 0 4.67157 0 5.5V6.5C0 7.32843 0.671573 8 1.5 8H7V4H8V8H13.5C14.3284 8 15 7.32843 15 6.5V5.5C15 4.67157 14.3284 4 13.5 4H12.6377C12.8667 3.65133 13 3.23408 13 2.78571V2.5C13 1.11929 11.8807 0 10.5 0C9.22684 0 8.11245 0.679792 7.5 1.69621C6.88755 0.679792 5.77316 0 4.5 0ZM8 4H10.7857C11.4563 4 12 3.45635 12 2.78571V2.5C12 1.67157 11.3284 1 10.5 1C9.11929 1 8 2.11929 8 3.5V4ZM7 4H4.21429C3.54365 4 3 3.45635 3 2.78571V2.5C3 1.67157 3.67157 1 4.5 1C5.88071 1 7 2.11929 7 3.5V4Z" fill="currentColor" />
      <path d="M7 9H1V12.5C1 13.8807 2.11929 15 3.5 15H7V9Z" fill="currentColor" />
      <path d="M8 15H11.5C12.8807 15 14 13.8807 14 12.5V9H8V15Z" fill="currentColor" />
    </svg>
  );
};

export default memo(VoucherIcon);