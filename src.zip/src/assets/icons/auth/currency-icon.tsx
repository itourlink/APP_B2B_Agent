interface Props {
  currentColor?: string;
}
export const CurrencyIcon = ({ currentColor = "#00000" }: Props) => {
  return (
 <svg fill={currentColor} width="800px" height="800px" viewBox="0 0 256 256" id="Flat" xmlns="http://www.w3.org/2000/svg">
  <path d="M152,116H140V60h4a28.03146,28.03146,0,0,1,28,28,12,12,0,0,0,24,0,52.059,52.059,0,0,0-52-52h-4V24a12,12,0,0,0-24,0V36h-8a52,52,0,0,0,0,104h8v56H104a28.03146,28.03146,0,0,1-28-28,12,12,0,0,0-24,0,52.059,52.059,0,0,0,52,52h12v12a12,12,0,0,0,24,0V220h12a52,52,0,0,0,0-104Zm-44,0a28,28,0,0,1,0-56h8v56Zm44,80H140V140h12a28,28,0,0,1,0,56Z"/>
</svg>
  );
};
