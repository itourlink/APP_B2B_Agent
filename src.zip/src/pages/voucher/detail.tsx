import VoucherDetail from "@/sections/voucher/components/voucher-detail";

const VoucherDetailPage = () => {
    return (
        <div>
            <VoucherDetail />
        </div>
    );
};

export default VoucherDetailPage;