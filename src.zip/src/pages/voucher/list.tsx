import VoucherList from "@/sections/voucher/components/voucher-list";

const VoucherListPage = () => {
    return (
        <div>
            <VoucherList />
        </div>
    );
};

export default VoucherListPage;